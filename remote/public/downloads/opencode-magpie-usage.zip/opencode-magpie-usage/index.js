// A server entry lets OpenCode load the package alongside its TUI entry.
// All functionality is client-side and on demand; no server hooks or tools.
export default { id: "nas.magpie-usage", setup() {} };
