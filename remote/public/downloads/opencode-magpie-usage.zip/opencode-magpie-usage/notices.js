import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
// The existing AmeTyping agent receives the NAS notices. This reader performs
// no gateway polling and shares delivery state across all local TUI windows.
export function watchNotices(ctx, { home = os.homedir(), now = Date.now, intervalMs = 30000 } = {}) {
  const dir = path.join(home, '.ametyping'), inbox = path.join(dir, 'quota-notices.json');
  const file = path.join(dir, 'quota-opencode-seen.json'), lock = file + '.lock';
  function check() {
    let fd;
    try {
      const raw = JSON.parse(fs.readFileSync(inbox, 'utf8'));
      if (!Array.isArray(raw.items)) return;
      try { if (now() - fs.statSync(lock).mtimeMs > 60000) fs.unlinkSync(lock); } catch {}
      fd = fs.openSync(lock, 'wx', 0o600);
      let seen = {}; try { seen = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
      seen = Object.fromEntries(Object.entries(seen).filter(([, t]) => Number.isFinite(t) && t > now()));
      // One toast per check so two simultaneous window thresholds don't hide each other.
      const n = raw.items.find(n => /^[a-f0-9]{24}$/.test(n.id) && !seen[n.id] && n.resetAt > now() && n.expiresAt > now() &&
        n.createdAt <= now() + 120000 && /^AGY Claude (周额度|5小时额度)即将重置$/.test(n.title) && /^(周额度|5小时额度)将在 \d{1,4}(小时|分钟)后重置。$/.test(n.body));
      if (n) {
        const left = n.resetAt - now(), time = left >= 3600000 ? Math.ceil(left / 3600000) + '小时' : Math.ceil(left / 60000) + '分钟';
        const label = n.title.includes('周额度') ? '周额度' : '5小时额度';
        ctx.ui.toast.show({ title: n.title, message: `${label}将在 ${time}后重置。`, variant: 'info', duration: 12000 }); seen[n.id] = n.expiresAt;
      }
      fs.writeFileSync(file + '.tmp', JSON.stringify(seen), { mode: 0o600 }); fs.renameSync(file + '.tmp', file);
    } catch {} finally { if (fd !== undefined) { fs.closeSync(fd); try { fs.unlinkSync(lock); } catch {} } }
  }
  const timer = setInterval(check, intervalMs); timer.unref?.(); check();
  return { check, dispose() { clearInterval(timer); } };
}
