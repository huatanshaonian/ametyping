import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

export function text(value, fallback = "未知") {
  if (typeof value !== "string" || !value.trim()) return fallback;
  return value.replace(/[\x00-\x1f\x7f]/g, " ")
    .replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "账号")
    .slice(0, 120);
}
const number = (value) => typeof value === "number" && Number.isFinite(value) ? value : undefined;
export const count = (value) => number(value) === undefined ? "未知" : new Intl.NumberFormat("zh-CN", {
  notation: value >= 10000 ? "compact" : "standard", maximumFractionDigits: 2,
}).format(value);
const money = (value) => number(value) === undefined ? "未知" : `$${value.toFixed(4)}`;

export function resetTime(value, now = Date.now()) {
  const date = typeof value === "string" ? Date.parse(value) : NaN;
  if (!Number.isFinite(date)) return "重置时间未知";
  const label = new Date(date).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false });
  const minutes = Math.ceil((date - now) / 60000);
  if (minutes <= 0) return `${label} 已到重置时间，等待来源更新`;
  const left = minutes >= 1440 ? `${Math.floor(minutes / 1440)}天${Math.floor(minutes % 1440 / 60)}小时`
    : minutes >= 60 ? `${Math.floor(minutes / 60)}小时${minutes % 60}分` : `${minutes}分`;
  return `${left}后重置 · ${label}`;
}
function percent(window) {
  if (window.unlimited === true) return "不限额";
  const remaining = number(window.remaining);
  return remaining === undefined ? "剩余未知" : `剩余 ${remaining.toFixed(1)}%`;
}
function bar(window) {
  const value = number(window.remaining);
  if (value === undefined || window.unlimited === true) return "";
  const filled = Math.round(Math.max(0, Math.min(100, value)) / 10);
  return "█".repeat(filled) + "░".repeat(10 - filled);
}
function windowName(value) {
  return text(value).replace(/7 days/gi, "7天").replace(/1 day/gi, "1天")
    .replace(/5 hours/gi, "5小时").replace(/^Credits$/i, "积分");
}
function sourceTime(value) {
  const date = typeof value === "string" ? Date.parse(value) : NaN;
  return Number.isFinite(date) ? new Date(date).toLocaleString("zh-CN", { hour12: false }) : "未知";
}

// Only selected summary fields reach the dialog. No user/email, raw error,
// upstream key identifiers, transcripts, or session titles are displayed.
export function rowsFor(snapshot, now = Date.now()) {
  const rows = [];
  const usage = snapshot.usage;
  if (usage) {
    const details = [
      "范围：NAS Magpie 今日全部调用（包含其他客户端），不是当前会话。",
      `请求 ${count(usage.calls)} · 错误 ${count(usage.errors)}`,
      `输入 ${count(usage.input)} · 输出 ${count(usage.output)} · 思考 ${count(usage.reasoning)}`,
      `缓存读取 ${count(usage.cache_read)} · 缓存写入 ${count(usage.cache_write)}`,
      `缓存状态未知 ${count(usage.cache_unknown)} tokens / ${count(usage.cache_unknown_calls)} 次调用`,
      "缓存状态未知不等于未命中。",
      `按模型单价估算：${money(usage.cost)}；不是订阅实际扣款。`,
      `未定价调用 ${count(usage.unpriced)} · 统计开始 ${sourceTime(usage.since)}`,
    ];
    rows.push({ value: "today", category: "今日用量", title: `${count(usage.calls)} 次请求 · 输入 ${count(usage.input)} · 输出 ${count(usage.output)}`,
      description: `缓存读取 ${count(usage.cache_read)} · 缓存未知 ${count(usage.cache_unknown_calls)} 次`,
      footer: `估算 ${money(usage.cost)}`, details: details.join("\n") });
  }
  if (snapshot.usageError) rows.push({ value: "usage-error", category: "今日用量", title: snapshot.usageError, details: snapshot.usageError });
  const records = Array.isArray(snapshot.quotas?.data) ? snapshot.quotas.data : [];
  const seenProviders = new Map();
  records.forEach((record, index) => {
    if (!record || typeof record !== "object") return;
    const provider = text(record.provider);
    const seq = (seenProviders.get(provider) ?? 0) + 1;
    seenProviders.set(provider, seq);
    const name = provider === "antigravity" ? "AGY" : text(record.name, provider);
    const keyLimit = !!record.from && /\/~keys$/.test(provider);
    const category = record.from ? `${provider.replace(/\/~keys$/, "").toUpperCase()} · Remote Magpie` : `${name}${record.plan ? " · " + text(record.plan) : " · 账号" + seq}`;
    const windows = Array.isArray(record.windows) ? record.windows : [];
    const seenPools = new Set();
    for (const [wi, window] of windows.entries()) {
      if (!window || typeof window !== "object") continue;
      // A pool can repeat under several model/effort labels; keep distinct
      // 5h/weekly windows even if they share a pool.
      const period = /7 days|7天|week/i.test(window.name ?? "") ? "week"
        : /5 hours|5小时/i.test(window.name ?? "") ? "5h" : "model";
      const poolKey = window.pool ? JSON.stringify([window.pool, period, window.remaining, window.resetsAt]) : undefined;
      if (poolKey && seenPools.has(poolKey)) continue;
      if (poolKey) seenPools.add(poolKey);
      const label = windowName(window.name);
      const amount = number(window.amount), limit = number(window.limit);
      const units = amount !== undefined && limit !== undefined ? `已用 ${count(amount)} / ${count(limit)} ${text(window.unit, "")}` : "";
      const reset = window.unlimited === true ? "" : resetTime(window.resetsAt, now);
      rows.push({ value: `quota-${index}-${wi}`, category,
        title: keyLimit ? `连接 Key 限额 · ${window.unlimited ? "未设置调用限额" : percent(window)}` : `${label} · ${percent(window)}`,
        description: [bar(window), units || reset].filter(Boolean).join("  "),
        details: [category, `${label}：${percent(window)}`, units, reset,
          `来源读取时间：${sourceTime(record.readAt)}`,
          record.error ? "来源返回了错误，此额度可能未刷新。" : "",
          record.from ? "来源：远端 Magpie" : "",
          keyLimit ? "这是本连接 Key 的限额，不代表远端上游订阅额度无限。" : "",
        ].filter(Boolean).join("\n") });
    }
    if (!windows.length) rows.push({ value: `empty-${index}`, category,
      title: /nothing read on that magpie yet/i.test(record.error || "") ? "上游订阅额度尚未读取" : record.error ? "上游额度读取失败" : "来源未提供额度", details: "请在 Magpie 检查该来源；未取得额度不代表额度为零。" });
  });
  if (snapshot.quotasError) rows.push({ value: "quotas-error", category: "订阅额度", title: snapshot.quotasError, details: snapshot.quotasError });
  if (!records.length && !snapshot.quotasError) rows.push({ value: "no-quotas", category: "订阅额度", title: "暂无额度数据", details: "来源尚未提供可显示的额度。" });
  return rows;
}

export async function connection(options = {}) {
  const configFile = options.configFile ?? join(homedir(), ".config", "opencode", "opencode.json");
  let config;
  try { config = JSON.parse((await readFile(configFile, "utf8")).replace(/^\uFEFF/, "")); }
  catch { throw new Error("OpenCode 网关配置不可读"); }
  const settings = config.providers?.magpie?.settings;
  let url;
  try { url = new URL(settings?.baseURL); } catch { throw new Error("Magpie 网关地址无效"); }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new Error("Magpie 网关地址无效");
  let key;
  try {
    // Reuse the existing dedicated NAS gateway key file. OpenCode's native
    // credential reference need not be a literal string in the saved JSON.
    // No resolved credential is written to this package or a UI config.
    const keyFile = options.keyFile ?? join(dirname(configFile), ".secrets", "magpie-nas.key");
    key = (await readFile(keyFile, "utf8")).trim();
    if (!key || /[\r\n]/.test(key)) throw new Error();
  } catch { throw new Error("Magpie 网关调用密钥不可读"); }
  return { baseURL: url.href.replace(/\/$/, ""), key };
}
export async function loadUsage({ signal, options = {}, fetcher = fetch, connect = connection } = {}) {
  let current;
  try { current = await connect(options); }
  catch (error) { return { quotasError: error.message, usageError: error.message, readAt: Date.now() }; }
  // This domain is the user's private LAN/Tailscale NAS gateway. The TUI
  // process can inherit different proxy variables from the managed server.
  const directGateway = new URL(current.baseURL).hostname === "magapi.huatan.org";
  const request = async (path) => {
    try {
      const response = await fetcher(`${current.baseURL}/magpie/${path}`, {
        ...(directGateway ? { proxy: false } : {}),
        headers: { Authorization: `Bearer ${current.key}` }, redirect: "error",
        signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(15000)]) : AbortSignal.timeout(15000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.text();
      if (body.length > 4 * 1024 * 1024) throw new Error("DATA_TOO_LARGE");
      return { value: JSON.parse(body) };
    } catch (error) {
      const status = /^HTTP [0-9]{3}$/.test(error.message) ? error.message : error.name === "TimeoutError" ? "连接超时" : "NAS 数据暂不可读";
      return { error: status };
    }
  };
  const [quotas, usage] = await Promise.all([request("quotas"), request("usage?period=today")]);
  current.key = undefined;
  return { quotas: quotas.value, usage: usage.value,
    quotasError: quotas.error && `额度：${quotas.error}`, usageError: usage.error && `今日用量：${usage.error}`, readAt: Date.now() };
}
