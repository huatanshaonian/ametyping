import { loadUsage, rowsFor } from "./data.js";
import { watchNotices } from "./notices.js";

// Plain Plugin.Definition is accepted by OpenCode 2.2.0. No runtime package,
// network polling, persistent UI slots, conversation tools or model calls.
export function createUsageCommand(ctx, read = loadUsage) {
  let active = false;
  let disposed = false;
  let controller;
  const open = async () => {
    if (active || disposed) return;
    active = true;
    let selected;
    try {
      let refresh = true;
      while (refresh && !disposed) {
        refresh = false;
        controller = new AbortController();
        ctx.ui.dialog.set({ size: "large", centered: true });
        const loading = ctx.ui.dialog.alert({ title: "Magpie 用量 · 读取中", message: "正在读取 NAS 额度与今日用量。Esc 取消。" });
        const result = await Promise.race([
          read({ signal: controller.signal, options: ctx.options }).then((snapshot) => ({ snapshot })),
          loading.then(() => ({ cancelled: true })),
        ]);
        if (result.cancelled || disposed) { controller.abort(); break; }
        ctx.ui.dialog.clear();
        const snapshot = result.snapshot;
        let viewing = true;
        while (viewing && !disposed) {
          const rows = rowsFor(snapshot);
          let action;
          ctx.ui.dialog.set({ size: "large", centered: true });
          const picked = await ctx.ui.dialog.select({
            title: `Magpie 用量 · ${new Date(snapshot.readAt).toLocaleTimeString("zh-CN", { hour12: false })}`,
            placeholder: "搜索额度 / 用量 · Enter 查看详情 · Esc 关闭",
            options: rows.map(({ details, ...row }) => row),
            current: selected,
            actions: [{ bind: "ctrl+r", title: "刷新", selection: "none", onTrigger: () => { action = "refresh"; ctx.ui.dialog.clear(); } }],
          });
          if (action === "refresh") { refresh = true; break; }
          if (picked === undefined || disposed) { viewing = false; break; }
          selected = picked;
          const row = rows.find((item) => item.value === picked);
          if (row) await ctx.ui.dialog.alert({ title: row.category, message: row.details });
        }
      }
    } catch {
      if (!disposed) await ctx.ui.dialog.alert({ title: "Magpie 用量", message: "用量暂不可读，请稍后重新打开。" });
    } finally {
      controller?.abort();
      active = false;
    }
  };
  return { open, dispose() { disposed = true; controller?.abort(); if (active) ctx.ui.dialog.clear(); } };
}

export default {
  id: "nas.magpie-usage",
  setup(ctx) {
    const command = createUsageCommand(ctx);
    const notices = watchNotices(ctx);
    ctx.keymap.layer(() => ({
      mode: "global", priority: 10,
      commands: [{ id: "usage.show", title: "Magpie 用量", group: "Agent", palette: true, bind: false,
        slash: { name: "usage", aliases: ["uasge"] }, run: command.open }],
    }));
    return () => { notices.dispose(); command.dispose(); };
  },
};
